﻿using Xamarin.Forms;

namespace ViewmodelFirstNavigation.Screens
{
    public partial class MainView : ContentPage
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
