﻿using System.Threading.Tasks;

namespace ViewmodelFirstNavigation
{
    public static class TaskExtensions
    {
        public static void FireAndForget(this Task task)
        {
            // Intentionally empty
        }
    }
}
